# Agritrust Login & Register System

A beautiful, modern authentication system with a stunning purple night sky background featuring stars and forest silhouettes. Built with pure HTML, CSS, and JavaScript.

## 🌟 Features

- **Beautiful Design**: Purple gradient background with animated stars and forest silhouette
- **Glassmorphism Effect**: Modern frosted glass appearance for form containers
- **Responsive Design**: Works perfectly on all device sizes
- **Form Validation**: Client-side validation with user-friendly error messages
- **Interactive Elements**: Hover effects, focus animations, and smooth transitions
- **Remember Me**: Local storage functionality for user preferences
- **Font Awesome Icons**: Professional icons for better user experience

## 📁 Files

- `index.html` - Landing page with navigation to login/register
- `login.html` - Login form with username, password, and remember me
- `register.html` - Registration form with username, email, and password fields
- `script.js` - JavaScript functionality for forms and interactions
- `README.md` - This documentation file

## 🚀 How to Use

1. **Open the landing page**: Start with `index.html` to see the welcome screen
2. **Navigate to forms**: Use the buttons to go to login or register pages
3. **Form functionality**: 
   - Login: Enter username and password, optionally check "Remember me"
   - Register: Fill in username, email, password, and confirm password
4. **Validation**: Forms will show helpful error messages for invalid inputs
5. **Success messages**: Green notifications appear for successful actions

## 🎨 Design Features

- **Background**: Purple gradient (#667eea to #764ba2) with animated stars
- **Forest Silhouette**: Dark purple forest shapes at the bottom
- **Glassmorphism**: Semi-transparent containers with backdrop blur
- **Typography**: Clean, modern Segoe UI font family
- **Colors**: Purple theme with white text and subtle shadows
- **Animations**: Smooth transitions, hover effects, and focus states

## 🔧 Customization

### Colors
- Primary gradient: `#667eea` to `#764ba2`
- Forest colors: `#2d1b69` to `#4a2b8a`
- Text colors: `#333` (dark), `#555` (medium), `#667eea` (accent)

### Styling
- Modify CSS variables in the `<style>` sections
- Adjust backdrop-filter blur values for different glass effects
- Change border-radius for different corner roundness
- Modify animation durations and easing functions

## 📱 Responsive Design

- **Desktop**: Full-width forms with optimal spacing
- **Tablet**: Adjusted padding and margins
- **Mobile**: Stacked buttons, reduced padding, optimized touch targets

## 🌐 Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## 🚀 Future Enhancements

- Backend integration with real authentication APIs
- Password strength indicators
- Social media login options
- Two-factor authentication
- Password recovery functionality
- User profile management

## 📝 Usage Examples

### Basic Form Submission
```javascript
// Forms automatically handle validation and submission
// Success/error messages are displayed automatically
// Redirects are handled after successful actions
```

### Custom Validation
```javascript
// Add custom validation rules in script.js
// Modify the form event listeners
// Customize error message display
```

## 🎯 Getting Started

1. Download all files to your web server
2. Open `index.html` in your browser
3. Navigate between login and register forms
4. Test the form validation and submission
5. Customize colors and styling as needed

## 📞 Support

For questions or customization help, refer to the code comments or modify the CSS variables in each HTML file.

---

**Built with ❤️ for modern web applications** 