// Form validation and functionality
document.addEventListener('DOMContentLoaded', function() {
    // Login form handling
    const loginForm = document.querySelector('form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = this.querySelector('input[type="text"]').value;
            const password = this.querySelector('input[type="password"]').value;
            const rememberMe = this.querySelector('input[type="checkbox"]').checked;
            
            if (!username || !password) {
                showMessage('Please fill in all fields', 'error');
                return;
            }
            
            // Show loading spinner
            const loginBtn = this.querySelector('.login-btn');
            const btnText = loginBtn.querySelector('.btn-text');
            const spinner = loginBtn.querySelector('.spinner');
            
            btnText.style.display = 'none';
            spinner.style.display = 'block';
            loginBtn.disabled = true;
            
            // Simulate login process
            showMessage('Logging in...', 'info');
            
            // Here you would typically make an API call to authenticate
            setTimeout(() => {
                showMessage('Login successful!', 'success');
                
                // Hide spinner and restore button
                btnText.style.display = 'inline';
                spinner.style.display = 'none';
                loginBtn.disabled = false;
                
                // Redirect to dashboard
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 1000);
            }, 1500);
        });
    }
    
    // Register form handling
    const registerForm = document.querySelector('form');
    if (registerForm && registerForm.querySelector('input[type="email"]')) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = this.querySelector('input[type="text"]').value;
            const email = this.querySelector('input[type="email"]').value;
            const password = this.querySelectorAll('input[type="password"]')[0].value;
            const confirmPassword = this.querySelectorAll('input[type="password"]')[1].value;
            
            if (!username || !email || !password || !confirmPassword) {
                showMessage('Please fill in all fields', 'error');
                return;
            }
            
            if (password !== confirmPassword) {
                showMessage('Passwords do not match', 'error');
                return;
            }
            
            if (password.length < 6) {
                showMessage('Password must be at least 6 characters long', 'error');
                return;
            }
            
            // Show loading spinner
            const registerBtn = this.querySelector('.register-btn');
            const btnText = registerBtn.querySelector('.btn-text');
            const spinner = registerBtn.querySelector('.spinner');
            
            btnText.style.display = 'none';
            spinner.style.display = 'flex';
            registerBtn.disabled = true;
            
            // Simulate registration process
            showMessage('Creating account...', 'info');
            
            // Here you would typically make an API call to register
            setTimeout(() => {
                showMessage('Registration successful!', 'success');
                
                // Hide spinner and restore button
                btnText.style.display = 'inline';
                spinner.style.display = 'none';
                registerBtn.disabled = false;
                
                // Redirect to login page
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 1500);
            }, 1500);
        });
    }
    
    // Input field animations
    const inputFields = document.querySelectorAll('.input-field');
    inputFields.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.02)';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });
    });
    
    // Remember me functionality
    const rememberMeCheckbox = document.querySelector('input[type="checkbox"]');
    if (rememberMeCheckbox) {
        // Load saved preference
        const savedPreference = localStorage.getItem('rememberMe');
        if (savedPreference === 'true') {
            rememberMeCheckbox.checked = true;
        }
        
        rememberMeCheckbox.addEventListener('change', function() {
            localStorage.setItem('rememberMe', this.checked);
        });
    }
});

// Message display function
function showMessage(message, type) {
    // Remove existing message
    const existingMessage = document.querySelector('.message');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.textContent = message;
    
    // Find the form container (login or register container)
    const formContainer = document.querySelector('.login-container, .register-container');
    
    // Style the message
    messageDiv.style.cssText = `
        position: absolute;
        top: -60px;
        left: 50%;
        transform: translateX(-50%);
        padding: 12px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 1000;
        animation: slideIn 0.3s ease-out;
        max-width: 300px;
        word-wrap: break-word;
        text-align: center;
        font-size: 14px;
    `;
    
    // Set background color based on type
    switch(type) {
        case 'success':
            messageDiv.style.background = '#4CAF50';
            break;
        case 'error':
            messageDiv.style.background = '#f44336';
            break;
        case 'info':
            messageDiv.style.background = '#2196F3';
            break;
        default:
            messageDiv.style.background = '#333';
    }
    
    // Add slide-in animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(-50%) translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateX(-50%) translateY(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Add to form container if found, otherwise to body
    if (formContainer) {
        formContainer.style.position = 'relative';
        formContainer.appendChild(messageDiv);
    } else {
        document.body.appendChild(messageDiv);
    }
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        messageDiv.style.animation = 'slideOut 0.3s ease-in forwards';
        setTimeout(() => {
            messageDiv.remove();
        }, 300);
    }, 3000);
    
    // Add slide-out animation
    const slideOutStyle = document.createElement('style');
    slideOutStyle.textContent = `
        @keyframes slideOut {
            from {
                transform: translateX(-50%) translateY(0);
                opacity: 1;
            }
            to {
                transform: translateX(-50%) translateY(-20px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(slideOutStyle);
}

// Add some interactive effects
document.addEventListener('DOMContentLoaded', function() {
    // Add hover effects to buttons
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px) scale(1.02)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Add focus effects to input fields
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.02)';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });
    });
}); 